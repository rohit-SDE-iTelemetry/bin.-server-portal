from django.db import models
from django.contrib.auth.models import User



class ProductsCategory(models.Model):
    productCategoryName = models.CharField(max_length=50, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class ProductsListing(models.Model):
    productName = models.CharField(max_length=50, blank=True)
    productCategory = models.ForeignKey(ProductsCategory,blank=True, on_delete=models.PROTECT)
    productImages = models.FileField(upload_to="Upload_Images/productImages/", null=True)
    productDescription = models.TextField()
    productDimension = models.CharField(max_length=50, blank=True)
    productPrice = models.CharField(max_length=10, blank=True)
    productQuantity = models.CharField(max_length=10, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
        return  self.productName
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['productName'], name='Product Listing')
        ]